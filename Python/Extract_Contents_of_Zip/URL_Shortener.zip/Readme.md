# URL Shortener

This script provides a shortened URL on the command line.

## Requirement for this script:

1. pyshorteners

install it by running the following command in the command prompt:

pip install pyshorteners

## How to use this script?

Just type the following in your command prompt:

python script.py

## Sample of the script in action:

![demo](https://user-images.githubusercontent.com/56690856/96848723-69df4800-1472-11eb-850e-aad8064eaf5e.png)